$(document).ready(function () {

// Open insert modal start
    $("#insertModalBtn").click(function() {
        $('#insertModal').modal('show');
        $( '#insertForm' ).each(function(){
            this.reset();
        });
        $("#emptyValuesInsert").addClass("d-none");
        $("#insertValueSent").addClass("d-none");
    });
    $("#closeInsertModal, #closeInsertModalBtn").click(function() {
        $('#insertModal').modal('hide');
        $( '#insertForm' ).each(function(){
            this.reset();
        });
        $("#emptyValuesInsert").addClass("d-none");
        $("#insertValueSent").addClass("d-none");
    });
    // $("#submitInsertData").click(function () { 
    $(document).on('click','#submitInsertData',function(){
        
        var errorChckInsrtFrm = '';
        $('.insertFormChckInput').each(function(){
            var frInpt = $(this).val();
            var frInptAttr = $(this).attr('insertattr');
            if(frInpt == ''){
                errorChckInsrtFrm += "• "+frInptAttr+'<br/>';
            }
        });
        if(errorChckInsrtFrm != ''){
            // alert('Please Select The Below Fields:\n'+errorChckInsrtFrm);
            $("#emptyValuesInsert").removeClass("d-none");

            document.getElementById("emptyValuesInsert").innerHTML = "Please fill out below fields: <br/>" + errorChckInsrtFrm;
            return false;
        }

        var insertProducts = $('#insertProducts').val();
        var insertWholesale = $('#insertWholesale').val();
        var insertPrice = $('#insertPrice').val();

        var insertArray = {'products':insertProducts,
        'wholesale':insertWholesale,
        'price':insertPrice};

        $.ajax({
            url: 'insertIndex',
            type: 'POST',
            beforeSend: function (xhr) {
                var token = $('meta[name="csrf_token"]').attr('content');

                if (token) {
                    return xhr.setRequestHeader('X-CSRF-TOKEN', token);
                }
            },
            data: insertArray,
            success: function (response) {
                // alert(response);
                $( '#insertForm' ).each(function(){
                    this.reset();
                });
                $("#emptyValuesInsert").addClass("d-none");
                $("#insertValueSent").removeClass("d-none");

                $('.table').load(' .table');

                $('#insertModal').modal('hide');
            },
            error: function (result) {
                // console.log(result);
                // alert('some error');
                Swal.fire({
                    icon: 'error',
                    text: 'Some Error'
                })
            }
        });

    });

// Open insert modal end

// Open Edit Modal Start

    // $(".editModalBtn").click(function() {
    $(document).on('click','.editModalBtn',function(){
        $('#editModal').modal('show');

        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function () {
            return $(this).text();
        }).get();

        // console.log(data);

        $('#edit_id').val(data[0]);
        $('#edit_product').val(data[1]);
        $('#edit_wholesale').val(data[2]);
        $('#edit_price').val(data[3]);

    });
    $("#closeEditModal, #closeEditModal").click(function() {
        $('#editModal').modal('hide');
    });

    // $("#submitEditData").click(function () { 
    $(document).on('click','#submitEditData',function(){
        var errorChckEditFrm = '';
        $('.editFormChckInput').each(function(){
            var frInpt = $(this).val();
            var frInptAttr = $(this).attr('editattr');
            if(frInpt == ''){
                errorChckEditFrm += "• "+frInptAttr+'<br/>';
            }
        });
        if(errorChckEditFrm != ''){
            // alert('Please Select The Below Fields:\n'+errorChckEditFrm);
            $("#emptyValuesEdit").removeClass("d-none");

            document.getElementById("emptyValuesEdit").innerHTML = "Please fill out below fields: <br/>" + errorChckEditFrm;
            return false;
        }

        var editId = $('#edit_id').val();
        var editProducts = $('#edit_product').val();
        var editWholesale = $('#edit_wholesale').val();
        var editPrice = $('#edit_price').val();

        var editArray = {'edit_id':editId,
        'edit_products':editProducts,
        'edit_wholesale':editWholesale,
        'edit_price':editPrice};

        // console.log(editArray);

        $.ajax({
            url: 'editIndex',
            type: 'POST',
            beforeSend: function (xhr) {
                var token = $('meta[name="csrf_token"]').attr('content');

                if (token) {
                    return xhr.setRequestHeader('X-CSRF-TOKEN', token);
                }
            },
            data: editArray,            
            success: function (response) {
                // alert(response);
                $( '#edittForm' ).each(function(){
                    this.reset();
                });
                $("#emptyValuesEdit").addClass("d-none");
                $("#editValueSent").removeClass("d-none");

                $('.table').load(' .table');

                $('#editModal').modal('hide');

            },
            error: function (result) {
                // console.log(result);
                // alert('some error');
                Swal.fire({
                    icon: 'error',
                    text: 'Some Error'
                })
            }
        });

    });

// Open Edit Modal End

// Open Delete Modal Start

    // $(".deleteModalBtn").click(function() {
    $(document).on('click','.deleteModalBtn',function(){
        $('#deleteModal').modal('show');

        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function () {
            return $(this).text();
        }).get();

        // console.log(data);

        $('#delete_id').val(data[0]);
        $('#delete_products').html(data[1]);
        $('#delete_wholesale').html(data[2]);
        $('#delete_price').html(data[3]);

    });
    $("#closeDeleteModal, #closeDeleteModal").click(function() {
        $('#deleteModal').modal('hide');
    });

    // $("#deleteDataBtn").click(function () { 
    $(document).on('click','#deleteDataBtn',function(){

        var deleteId = $('#delete_id').val();

        var deleteArray = {'delete_id':deleteId};

        // console.log(deleteId);

        $.ajax({
            url: 'deleteIndex',
            type: 'POST',
            beforeSend: function (xhr) {
                var token = $('meta[name="csrf_token"]').attr('content');

                if (token) {
                    return xhr.setRequestHeader('X-CSRF-TOKEN', token);
                }
            },
            data: deleteArray,            
            success: function (response) {
                // alert(response);
                $( '#deleteForm' ).each(function(){
                    this.reset();
                });

                $('.table').load(' .table');

                $('#deleteModal').modal('hide');

            },
            error: function (result) {
                // console.log(result);
                // alert('some error');
                Swal.fire({
                    icon: 'error',
                    text: 'Some Error'
                })
            }
        });

    });

// Open Delete Modal End

});