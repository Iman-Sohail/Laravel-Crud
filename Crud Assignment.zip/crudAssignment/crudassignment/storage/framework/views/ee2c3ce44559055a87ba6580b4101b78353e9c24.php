

<?php $__env->startSection('title', 'Crud'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $productData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsproductData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <!-- jQuery File -->
    <script src="<?php echo e(URL('assets/javascript/jquery_3.6.1.min.js')); ?>"></script>

    <script>

    $(document).ready(function () {

        $(document).on('keyup','#qtyChckInput_<?php echo e($rsproductData->id); ?>',function(){

            prodQty_<?php echo e($rsproductData->id); ?> = $('#qtyChckInput_<?php echo e($rsproductData->id); ?>').val();

            prodPrice_<?php echo e($rsproductData->id); ?> = $('#prodPrice_<?php echo e($rsproductData->id); ?>').html();

            var totalPrice = $('#totalPrice_<?php echo e($rsproductData->id); ?>').html(prodPrice_<?php echo e($rsproductData->id); ?> * prodQty_<?php echo e($rsproductData->id); ?>);

            var totalPriceVal = $('#totalPrice_<?php echo e($rsproductData->id); ?>').html();

            var itemTotal = $('#itemTotal').html(totalPriceVal);
            
            var itemTotalVal = $('#itemTotal').html();

            var itemDiscount = itemTotalVal * (1 - 10 / 100);

            $('#itemDiscount').html(itemTotalVal - itemDiscount);

            var itemTax = itemTotalVal * (1 - 5 / 100);

            $('#itemTax').html(itemTotalVal - itemTax);

            var itemGrand = itemTax + itemDiscount - itemTotalVal;

            var itemGrandVal = itemGrand + parseInt($('#itemTax').html());

            $('#itemGrand').html(itemGrandVal);

            item_total_data();

        });
        // To get total dynamically End

        function item_total_data() {
            var ItemTotal = 0;
            $('.total_Price').each(function(){
                ItemTotal += +$(this).text();
            });
            $('#itemTotal').html(ItemTotal);    
        }
        

    });

    </script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mt-2 container">

    <div class="text-center mb-5">
        <h2>Crud Table</h2>
        <button class="btn btn-primary" id="insertModalBtn">Insert Data</button>
    </div>

    <div class="table-responsive">
        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Products</th>
                    <th>Wholesale</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>EDIT</th>
                    <th>DELETE</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsproductData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td><?php echo e($rsproductData->id); ?></td>
                        <td><?php echo e($rsproductData->products); ?></td>
                        <td><?php echo e($rsproductData->wholesale); ?></td>
                        <td id="prodPrice_<?php echo e($rsproductData->id); ?>"><?php echo e($rsproductData->price); ?></td>
                        <td><input type="number" min="0" id="qtyChckInput_<?php echo e($rsproductData->id); ?>" class="form-control mb-2" name="qty"></td>
                        <td id="totalPrice_<?php echo e($rsproductData->id); ?>" class="total_Price">0</td>
                        <td><button class="btn btn-success editModalBtn">Edit</button></td>
                        <td><button class="btn btn-danger deleteModalBtn">Delete</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tfoot>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                            <th>Item Total</th>
                            <td id="itemTotal">0</td>
                            <td></td><td></td>
                        </tr>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                            <th>10% discount on Item Total</th>
                            <td id="itemDiscount">0</td>
                            <td></td><td></td>
                        </tr>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                            <th>5% Tax on Item Total</th>
                            <td id="itemTax">0</td>
                            <td></td><td></td>
                        </tr>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                            <th>Grand Total</th>
                            <td id="itemGrand">0</td>
                            <td></td><td></td>
                        </tr>
                    </tfoot>
            </tbody>
        </table>
    </div>

    
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="editModalLabel">Edit Modal</h1>
                    <button type="button" id="closeEditModal" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="editForm">
                    <div class="modal-body">
                        <input type="hidden" id="edit_id" name="edit_id">

                        <div class="alert alert-danger d-none" id="emptyValuesEdit"></div>
                        <div class="mb3">
                            <label class="form-label">Enter products</label>
                            <input type="text" class="form-control editFormChckInput mb-2" editattr="Enter Products" name="edit_products" id="edit_product" required>
                            <div class="alert alert-danger d-none">Please enter correct product name</div>
                        </div>
                        <div class="mb3">
                            <label class="form-label">Enter wholesale</label>
                            <input type="number" class="form-control editFormChckInput mb-2" editattr="Enter Wholesale" name="edit_wholesale" id="edit_wholesale" required>
                            <div class="alert alert-danger d-none">Please enter correct wholesale rates</div>
                        </div>
                        <div class="mb3">
                            <label class="form-label">Enter price</label>
                            <input type="number" class="form-control editFormChckInput mb-2" editattr="Enter Price" name="edit_price" id="edit_price" required>
                            <div class="alert alert-danger d-none">Please enter correct price</div>
                        </div>
                        <div class="alert alert-success d-none" id="editValueSent">Your data has been submitted.</div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" id="closeEditModal" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="button" id="submitEditData" class="btn btn-success" value="Update Data">
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="deleteModalLabel">Delete Modal</h1>
                    <button type="button" id="closeDeleteModal" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="deleteForm">
                    <div class="modal-body">
                        <input type="hidden" name="delete_id" id="delete_id">
                        <div class="mb3">
                            <p class="alert alert-danger">Are you sure you want to delete following data?</p>
                            <span><b>Product Name:</b></span><p id="delete_products"></p>
                            <span><b>Product Wholesale:</b></span><p id="delete_wholesale"></p>
                            <span><b>Product Price:</b></span><p id="delete_price"></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="closeDeleteModal" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" id="deleteDataBtn" class="btn btn-danger">Delete Entry</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    
    <div class="modal fade" id="insertModal" tabindex="-1" aria-labelledby="insertModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="insertModalLabel">Insert Data</h1>
                    <button type="button" id="closeInsertModal" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="insertForm">
                <div class="modal-body">
                    <div class="alert alert-danger d-none" id="emptyValuesInsert"></div>
                    <div class="mb3">
                        <label class="form-label">Enter products</label>
                        <input type="text" class="form-control insertFormChckInput mb-2" insertattr="Enter Products" name="products" id="insertProducts" required>
                        <div class="alert alert-danger d-none">Please enter correct product name</div>
                    </div>
                    <div class="mb3">
                        <label class="form-label">Enter wholesale</label>
                        <input type="number" class="form-control insertFormChckInput mb-2" insertattr="Enter Wholesale" name="wholesale" id="insertWholesale" required>
                        <div class="alert alert-danger d-none">Please enter correct wholesale rates</div>
                    </div>
                    <div class="mb3">
                        <label class="form-label">Enter price</label>
                        <input type="number" class="form-control insertFormChckInput mb-2" insertattr="Enter Price" name="price" id="insertPrice" required>
                        <div class="alert alert-danger d-none">Please enter correct price</div>
                    </div>
                    <div class="alert alert-success d-none" id="insertValueSent">Your data has been submitted.</div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="closeInsertModalBtn" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="button" id="submitInsertData" class="btn btn-primary" value="Submit Data">
                </div>
            </form>
        </div>
    </div>
    
</div>
      
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\crudAssignment\crudassignment\resources\views/index.blade.php ENDPATH**/ ?>