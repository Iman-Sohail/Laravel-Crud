<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://dummyimage.com/65x65/000/fff&text=Favicon" type="image/x-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet" />

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="<?php echo e(URL('assets/fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('assets/fontawesome/css/fontawesome.min.css')); ?>">

    <!-- Cutom CSS -->
    <link rel="stylesheet" href="<?php echo e(URL('assets/css/style.css')); ?>">

    <!-- CSS only -->
    <link href="<?php echo e(URL('assets/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">
    
    <!-- Sweet Alert CSS -->
    <link rel="stylesheet" href="<?php echo e(URL('assets/sweet_alert/sweetalert2.min.css')); ?>">
</head><?php /**PATH F:\laragon\www\crudAssignment\crudassignment\resources\views/includes/head.blade.php ENDPATH**/ ?>