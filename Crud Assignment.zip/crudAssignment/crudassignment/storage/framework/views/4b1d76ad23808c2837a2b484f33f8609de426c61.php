
<!-- Font Awesome JS -->
<script src="<?php echo e(URL('assets/fontawesome/js/all.min.js')); ?>"></script>
<script src="<?php echo e(URL('assets/fontawesome/js/fontawesome.min.js')); ?>"></script>
<!-- JavaScript Bundle with Popper -->
<script src="<?php echo e(URL('assets/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<!-- jQuery File -->
<script src="<?php echo e(URL('assets/javascript/jquery_3.6.1.min.js')); ?>"></script>
<!-- Custom JavaScript -->
<script src="<?php echo e(URL('assets/javascript/script.js')); ?>"></script>

<script src="https://www.google.com/recaptcha/api.js"></script>
<!-- Sweet Alert Js -->
<script src="<?php echo e(URL('assets/sweet_alert/sweetalert2.min.js')); ?>"></script><?php /**PATH F:\laragon\www\crudAssignment\crudassignment\resources\views/includes/footer.blade.php ENDPATH**/ ?>