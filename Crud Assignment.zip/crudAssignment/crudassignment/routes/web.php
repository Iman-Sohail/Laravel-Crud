<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Index;

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/', 'Index@index');
// Route::post('/insertIndex', 'Index@insertIndex');


Route::get('/', [Index::class, 'index']);
Route::post('/insertIndex', [Index::class, 'insertIndex']);
Route::post('/editIndex', [Index::class, 'editIndex']);
Route::post('/deleteIndex', [Index::class, 'deleteIndex']);


Route::get('/configcachecleared', function() {
    $exitCode = Artisan::call('config:cache');
    return '<h1>Clear Config cleared</h1>';
});
//Clear Cache facade value:
Route::get('/clearcached', function() {
    $exitCode = Artisan::call('cache:clear');
    return '<h1>Cache facade value cleared</h1>';
});
Route::get('/clearviewed', function() {
    $exitCode = Artisan::call('view:clear');
    return '<h1>Cache view value cleared</h1>';
});