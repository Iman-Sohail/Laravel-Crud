
<!-- Font Awesome JS -->
<script src="{{URL('assets/fontawesome/js/all.min.js')}}"></script>
<script src="{{URL('assets/fontawesome/js/fontawesome.min.js')}}"></script>
<!-- JavaScript Bundle with Popper -->
<script src="{{ URL('assets/bootstrap/bootstrap.bundle.min.js') }}"></script>
<!-- jQuery File -->
<script src="{{ URL('assets/javascript/jquery_3.6.1.min.js') }}"></script>
<!-- Custom JavaScript -->
<script src="{{ URL('assets/javascript/script.js')}}"></script>
{{-- Google ReCaptcha Api --}}
<script src="https://www.google.com/recaptcha/api.js"></script>
<!-- Sweet Alert Js -->
<script src="{{URL('assets/sweet_alert/sweetalert2.min.js')}}"></script>