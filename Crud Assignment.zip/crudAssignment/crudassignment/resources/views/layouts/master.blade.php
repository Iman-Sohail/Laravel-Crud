<!DOCTYPE html>
<html>
    @include('includes.head')
    <body>
        @yield('content')
        @include('includes.footer')
    </body>
</html>