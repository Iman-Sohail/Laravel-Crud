<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Models\productData;
Use View;
Use DB;
Use Mail;
use Session;


class Index extends BaseController
{
    public function index(Request $request) {
        
        $productData =  productData::select('id', 'products', 'wholesale', 'price')->get();

        return view('index', ['productData' => $productData]);
    }

    public function insertIndex(Request $request) {
        
        // dd($request->products);

        $Ineruser = new productData();
        $Ineruser->products = $request->products;
        $Ineruser->wholesale = $request->wholesale;
        $Ineruser->price = $request->price;
        $Ineruser->save();
        
    }

    public function editIndex(Request $request) {

        // dd($request->edit_id);

        productData::where('id',$request->edit_id)
        ->update(array(
            'products' => $request->edit_products,
            'wholesale' => $request->edit_wholesale,
            'price' => $request->edit_price,
        ));

    }

    public function deleteIndex(Request $request) {

        // dd($request->delete_id);

        productData::where('id', $request->delete_id)->delete();

    }
}
